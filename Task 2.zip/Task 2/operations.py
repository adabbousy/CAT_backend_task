operations = input().strip("[]").replace('"', '').split(", ")
result = 0

for operation in operations:
    if operation == "++":
        result += 1
    elif operation == "--":
        result -= 1

print(result)
