CREATE DATABASE products;
USE products;


CREATE TABLE product(
product_id INT,
product_name VARCHAR(255),
is_recyclable BOOLEAN,
is_low_fat BOOLEAN
);

INSERT INTO product (product_id, product_name, is_recyclable, is_low_fat)
VALUES (1, 'Product A', TRUE, TRUE),
(2, 'Product B', TRUE, FALSE),
(3, 'Product C', FALSE, TRUE),
(4, 'Product D', TRUE, TRUE);


SELECT product_id, product_name FROM product 
WHERE is_recyclable is TRUE AND is_low_fat is TRUE;