import argparse
import csv
import os
import re
from werkzeug.security import check_password_hash, generate_password_hash

# File to store user data
USERS_FILE = "users.csv"
# Headers for the CSV file
HEADERS = ["username", "email", "password"]
# Dashed line for printing messages
DASHED_LINE = "-"*50


# Create the user data file with headers if it doesn't exist
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w") as file:
        writer = csv.DictWriter(file, fieldnames=HEADERS)
        writer.writeheader()


# Print messages with a dashed line separator
def print_message(message):
    print(f"{DASHED_LINE}\n{message}\n{DASHED_LINE}")


# Validate username based on requirements
def validate_username(username):
    # Username must be between 3 and 15 characters long (inclusive)
    if len(username) < 3 or len(username) > 15:
        print_message("Username must be 3 to 15 characters long.")
        return False

    # Username must contain only alphanumeric characters or underscores
    pattern = r'^[a-zA-Z0-9_]+$'
    if not re.match(pattern, username):
        print_message("Username can only contain letters, numbers, or underscore.")
        return False

    return True


# Validate email based on requirements
def validate_email(email):
    # Regex to check if email is in a valid format
    pattern = r'^[\w\.-]+@([\w-]+\.)+[a-zA-Z]{2,4}$'
    if not re.match(pattern, email):
        print_message("Invalid email format.")
        return False

    return True


# Validate password based on requirements
def validate_password(password):
    # Password must contain at least:
    # - 6 characters
    # - 1 lowercase letter
    # - 1 uppercase letter
    # - 1 number
    # - 1 special character (@$!%*?&)
    pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$'
    if not re.search(pattern, password):
        print_message("Password must contain at least\n- 6 characters\n- 1 lowercase letter\n"
                      "- 1 uppercase letter\n- 1 number\n- 1 special character (@$!%*?&)")
        return False

    return True


# Register a new user
def register():
    while True:
        # Get user inputs for registration
        username = input("Username: ").strip()
        email = input("Email: ").strip().lower()
        password = input("Password: ").strip()
        confirm_password = input("Confirm Password: ").strip()

        # Validate user inputs, reprompt if not valid
        if not validate_username(username):
            continue
        if not validate_email(email):
            continue
        if not validate_password(password):
            continue
        if confirm_password != password:
            print_message("Passwords do not match.")
            continue

        with open(USERS_FILE, "r") as file:
            users = csv.DictReader(file)
            # Check if username or email already exists
            for row in users:
                if row["username"] == username:
                    print_message(f"The username '{username}' is taken.")
                    break
                if row["email"] == email:
                    print_message("A user with this email exists.")
                    break
            else:
                # If username and email are unique, save the user into the data file
                with open(USERS_FILE, "a") as file:
                    writer = csv.DictWriter(file, fieldnames=HEADERS)
                    writer.writerow({"username": username,
                                    "email": email,
                                     "password": generate_password_hash(password)})

                print_message("User Registered successfully!")
                break


# Login an existing user
def login():
    # Get user inputs for login
    email = input("Email: ").strip().lower()
    password = input("Password: ").strip()

    with open(USERS_FILE, "r") as file:
        users = csv.DictReader(file)
        # Check if email and password match an existing user
        for row in users:
            if row["email"] == email and check_password_hash(row["password"], password):
                print_message(f"Welcome back, {row['username'].title()}! You are now logged in.")
                return
    print_message("Invalid email or password")


def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["register", "login"],
                        help="Action to perform (register or login)")
    args = parser.parse_args()

    # Call function base on action
    if args.action == "register":
        register()
    elif args.action == "login":
        login()


if __name__ == "__main__":
    main()
