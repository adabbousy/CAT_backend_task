# User Registration and Login System

This Python-based user registration and login system allows users to create a new account and log in securely by validating and storing user data in a CSV file. The system uses hashed passwords for security and provides input validation for usernames, emails, and passwords. The program uses command-line arguments that support both actions: registering and logging in.

## Features

- **User Registration**:
  - Ensures both username and email are unique and meet the requirements.
  - Password complexity requirements:
    - At least 6 characters long.
    - Must contain at least 1 lowercase letter, 1 uppercase letter, 1 number, and 1 special character (from `@$!%*?&`).
  - Passwords are securely hashed using `werkzeug.security`.
  - Provides clear error messages and prompts to help users through the registration process.

- **User Login**:
  - Users can log in by providing their registered email and password.
  - Error messages guide users in case of invalid inputs.

- **Data Storage**:
  - Stores user data (username, email, password) in a CSV file (`users.csv`).
  - Automatically creates the file with the proper headers if it doesn't already exist.

## Requirements

- Python 3.x
- `werkzeug` library (for password hashing)

    To install the necessary library, run:
    ```
    pip install werkzeug
    ```

## Usage
1. **Register a New User**:  
    Run the program with the `register` action:
    ```
    python authorization.py register
    ```
    Enter the required information (username, email, password, and password confirmation).

2. **Log In an Existing User**:  
    Run the program with the `login` action:  
    ```
    python authorization.py login
    ```
    Provide the registered email and password to log in.

## Example  
### Register a New User
```
$ python authorization.py register
Username: a_dabbousy
Email: abdullah@gmail.com
Password: Password123!
Confirm Password: Password123!
--------------------------------------------------
User Registered successfully!
--------------------------------------------------
```
### Log In  
```
$ python authorization.py login
Email: abdullah@gmail.com
Password: Password123!
--------------------------------------------------
Welcome back, A_dabbousy! You are now logged in.
--------------------------------------------------
``` 
